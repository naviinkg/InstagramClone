package com.example.instagramclone.instagramclone.repository;

import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBMapper;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBSaveExpression;
import com.amazonaws.services.dynamodbv2.model.AttributeValue;
import com.amazonaws.services.dynamodbv2.model.ExpectedAttributeValue;
import com.example.instagramclone.instagramclone.model.User;

import java.util.List;

@Repository
public class UserRepository {

    @Autowired
    private DynamoDBMapper dynamoDBMapper;

    public User createUser(User user) {
        // encrypt password
        System.out.println("here in repo");
        dynamoDBMapper.save(user);
        return user;
    }

    public User getUser(String userId) {
        System.out.println("user repo get user");
        return dynamoDBMapper.load(User.class, userId);
    }

    public User updateUserById(String userId, User user) {
        dynamoDBMapper.save(user,
                new DynamoDBSaveExpression()
                        .withExpectedEntry("id",
                                new ExpectedAttributeValue(
                                        new AttributeValue().withS(userId))));

        return user;
    }

    public User deleteUserById(String userId) {
        User user = dynamoDBMapper.load(User.class, userId);
        dynamoDBMapper.delete(user);
        return user;
    }

    public String follow(String userId, String followingId) {
        User user = dynamoDBMapper.load(User.class, userId);
        User following = dynamoDBMapper.load(User.class, followingId);

        if (Objects.nonNull(following)) {
            List<User> followingList = user.getFollowing();
            if (followingList.contains(following))
                return "You are already Following " + following.getName() + "";
            followingList.add(following);

            user.setFollowing(followingList);
            updateUserById(userId, user);

            return "Started following " + following.getName();

        }

        return "No such user found";
    }

    public String unFollow(String userId, String followingId) {
        User user = dynamoDBMapper.load(User.class, userId);
        User following = dynamoDBMapper.load(User.class, followingId);

        if (Objects.nonNull(following)) {
            List<User> followingList = user.getFollowing();

            if (followingList.contains(following))
                followingList.remove(following);
            else
                return " No such following user found";

            user.setFollowing(followingList);
            updateUserById(userId, user);

            return "Unfollowed " + following.getName();

        }

        return "No such user found";
    }

    public User signIn(User userDetails) {
        User user = dynamoDBMapper.load(User.class, userDetails.getId());

        if (Objects.nonNull(user) && user.getPassword().equals(userDetails.getPassword()))// decrypt password
            return user;

        return null;
    }

    public String signOut() {
        // to be implemented

        return "";
    }

}
