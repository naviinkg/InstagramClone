package com.example.instagramclone.instagramclone.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.instagramclone.instagramclone.repository.UserRepository;
import com.example.instagramclone.instagramclone.model.User;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestParam;

@RestController
public class UserController {

    @Autowired
    public UserRepository userRepository;

    @PostMapping("/user")
    public User createUser(@RequestBody User user) {
        System.out.println("here in controller");
        return userRepository.createUser(user);
    }

    @GetMapping("/user/{id}")
    public User getUser(@PathVariable("id") String userId) {
        return userRepository.getUser(userId);
    }

    @PutMapping("user/{id}")
    public User updateUserById(@PathVariable String id, @RequestBody User user) {
        return userRepository.updateUserById(id, user);
    }

    @DeleteMapping("user/{id}")
    public User deleteUserById(@PathVariable String id) {
        return userRepository.deleteUserById(id);
    }

    @GetMapping("user/{user_id}/follow/{follow_id}")
    public String follow(@PathVariable String user_id, @PathVariable String follow_id) {
        return userRepository.follow(user_id, follow_id);
    }

    @GetMapping("user/{user_id}/unFollow/{follow_id}")
    public String unFollow(@PathVariable String user_id, @PathVariable String follow_id) {
        return userRepository.unFollow(user_id, follow_id);
    }

    @PostMapping("/user/signIn")
    public User userSignIn(@RequestBody User user) {
        return userRepository.signIn(user);
    }

    // @GetMapping("/user/signout")
    // public String userSignOut(@RequestParam String param) {
    // return userRepository.signOut();
    // }

    // @PostMapping("/user/addUserToRequestList")
    // public String addUserToRequestList(@RequestBody User user) {
    // return "";
    // }

}
