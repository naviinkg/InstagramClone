package com.example.instagramclone.instagramclone.repository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBMapper;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBSaveExpression;
import com.amazonaws.services.dynamodbv2.model.AttributeValue;
import com.amazonaws.services.dynamodbv2.model.ExpectedAttributeValue;
import com.example.instagramclone.instagramclone.model.Post;
import com.example.instagramclone.instagramclone.model.Comment;

import java.util.List;
import java.util.Objects;

@Repository
public class PostRepository {

    @Autowired
    private DynamoDBMapper dynamoDBMapper;

    public Post createPost(Post post) {
        dynamoDBMapper.save(post);
        return post;
    }

    public Post gePost(String postId) {
        return dynamoDBMapper.load(Post.class, postId);
    }

    public String updatePostById(String id, Post post) {
        // checks if the post already exists, if it exists it updates or else throws
        // error
        dynamoDBMapper.save(post,
                new DynamoDBSaveExpression()
                        .withExpectedEntry("id",
                                new ExpectedAttributeValue(
                                        new AttributeValue().withS(id))));

        return id;
    }

    public Post deletePostById(String id) {
        Post post = dynamoDBMapper.load(Post.class, id);
        if (Objects.nonNull(post))
            dynamoDBMapper.delete(post);
        return post;
    }

    public String likePost(String id, String user_id) {
        Post post = dynamoDBMapper.load(Post.class, id);

        if (Objects.isNull(post))
            return "No such post";

        if (post.getLikes().contains(user_id))
            return "You already liked this post";

        List<String> likes = post.getLikes();
        likes.add(user_id);

        post.setLikes(likes);

        if (updatePostById(id, post).equals(id)) {
            return "Liked ";
        } else
            return "Problem in updating";

    }

    public String unLikePost(String id, String user_id) {
        Post post = dynamoDBMapper.load(Post.class, id);

        if (!post.getLikes().contains(user_id))
            return "Like the post first";

        List<String> likes = post.getLikes();
        likes.remove(user_id);

        post.setLikes(likes);

        if (updatePostById(id, post).equals(id)) {
            return "UnLiked ";
        } else
            return "Problem in updating";
    }

    public String commentPost(String id, String user_id, String message) {
        Post post = dynamoDBMapper.load(Post.class, id);

        List<Comment> comments = post.getComments();
        comments.add(new Comment(id, message, user_id));

        if (updatePostById(id, post).equals(id))
            return "Comment Successful";
        else
            return "Problem in updating";
    }

    public String unCommentPost(String id, String user_id, String message) {
        Post post = dynamoDBMapper.load(Post.class, id);

        List<Comment> comments = post.getComments();
        Comment comment = new Comment(id, message, user_id);

        if (comments.contains(comment))
            comments.remove(comment);
        else
            return "No comment found";

        if (updatePostById(id, post).equals(id))
            return "UnComment Successful";
        else
            return "Problem in updating";
    }
}
