package com.example.instagramclone.instagramclone.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.instagramclone.instagramclone.repository.PostRepository;
import com.example.instagramclone.instagramclone.model.Post;
import com.example.instagramclone.instagramclone.model.Comment;
import org.springframework.web.bind.annotation.PutMapping;

@RestController
public class PostController {

    @Autowired
    private PostRepository postRepository;

    @PostMapping("/post")
    public Post createPost(@RequestBody Post post) {
        System.out.println("create post");
        return postRepository.createPost(post);
    }

    @GetMapping("/post/{id}")
    public Post getPostById(@PathVariable("id") String id) {
        return postRepository.gePost(id);
    }

    @PutMapping("post/{id}")
    public String updatePostById(@PathVariable("id") String id, @RequestBody Post post) {
        return postRepository.updatePostById(id, post);
    }

    @DeleteMapping("post/{id}")
    public Post deletePostById(@PathVariable("id") String id) {
        return postRepository.deletePostById(id);
    }

    @GetMapping("/post/{post_id}/like/{user_id}")
    public String likePost(@PathVariable String user_id, @PathVariable String post_id) {
        return postRepository.likePost(post_id, user_id);
    }

    @GetMapping("/post/{post_id}/unLike/{user_id}")
    public String unLikePost(@PathVariable String user_id, @PathVariable String post_id) {
        return postRepository.unLikePost(post_id, user_id);
    }

    @PostMapping("/post/{post_id}/comment")
    public String commentPost(@RequestBody Comment comment) {
        return postRepository.commentPost(comment.getPost_id(), comment.getUser_id(), comment.getMessage());
    }

    @PostMapping("/post/{post_id}/unComment")
    public String UnCommentPost(@RequestBody Comment comment) {
        return postRepository.unCommentPost(comment.getPost_id(), comment.getUser_id(), comment.getMessage());
    }
}
