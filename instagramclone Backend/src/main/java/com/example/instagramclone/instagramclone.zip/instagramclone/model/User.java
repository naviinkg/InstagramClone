package com.example.instagramclone.instagramclone.model;

import com.amazonaws.services.dynamodbv2.datamodeling.*;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
@DynamoDBTable(tableName = "UserDetails")
public class User {

    @DynamoDBHashKey(attributeName = "id")
    private String id;
    @DynamoDBAttribute
    private String name;
    @DynamoDBAttribute
    private String email;
    @DynamoDBAttribute
    private String password;
    @DynamoDBAttribute
    private List<User> followers;
    @DynamoDBAttribute
    private List<User> following;
    @DynamoDBAttribute
    private List<Post> posts;
    // @DynamoDBAttribute
    // private List<User> requests;
}
