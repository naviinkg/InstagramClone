package com.example.instagramclone.instagramclone.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import java.util.List;

import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBAttribute;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBHashKey;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBTable;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@DynamoDBTable(tableName = "Post")
public class Post {

    @DynamoDBHashKey(attributeName = "id")
    private String id;
    @DynamoDBAttribute
    private String user_id;
    @DynamoDBAttribute
    private String caption;
    @DynamoDBAttribute
    private byte[] image; // check how to store image in Dynamo
    @DynamoDBAttribute
    private String dateTime;
    @DynamoDBAttribute
    private List<String> likes;
    @DynamoDBAttribute
    private List<Comment> comments;
}
